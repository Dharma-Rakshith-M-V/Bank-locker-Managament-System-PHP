  <footer class="main-footer">
    <strong><a href="#">Bank Locker Management System</a>.</strong>

  </footer>